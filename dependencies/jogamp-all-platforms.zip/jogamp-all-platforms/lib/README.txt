This folder contains platform folders with deprecated plain native libraries, please use the native JAR files in the jar folder.
